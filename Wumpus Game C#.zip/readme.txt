A sample of the code is in wumpus_code_txt.cs
the actual code is in wumpus/wumpus/program.cs.